# BoltFN
![image-3](https://github.com/user-attachments/assets/54c17d55-dd88-46e6-b580-96be7ebe2080)

Fortnite account checker using Microsoft authentication. Has many captures including skins
DISCORD: [https://discord.gg/pFQDrMSJXw](https://discord.gg/pFQDrMSJXw)

Features:
Full Capture Mode,
Brute Mode
Clean UI,
Multithreading,
3 CUI modes and Log mode,
Proxy scraper,
Combo editor (13 different modes),

Captures:
Skins (accounts with unobtainable/og skins saved seperately in results folder otherwise sorted into quantities eg 1-9, 10-49 ect),
NFA (non full access) or FA (full access),
Vbucks,
Save the world,
first active season,
total wins,
total level,
backblings,
gliders,
pickaxes,
emotes,
2fa (two factor authentication),
Country

Proxy format:
ip:port 
OR
user:pass@ip:port 

Usage:
open cmd in directory
pip install -r requirements.txt
py boltchecker.py
OR
python boltchecker.py
(depends on python installation)
If you have any issues uninstall python then install version 3.12 make sure to select add to path

DO NOT TRY AND SELL THIS AS YOUR OWN. I made this open source so that people could have something nice for free and maybe learn some python don't take advantage of that.
